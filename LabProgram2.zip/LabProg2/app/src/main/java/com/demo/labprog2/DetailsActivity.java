package com.demo.labprog2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {

    TextView name,usn,dept;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        name = findViewById(R.id.lbl_name);
        usn = findViewById(R.id.lbl_usn);
        dept = findViewById(R.id.lbl_dept);

        Intent i = getIntent();
        String nameVal = i.getStringExtra("name_key");
        String usnVal = i.getStringExtra("usn_key");
        String deptVal = i.getStringExtra("dept_key");

        name.setText(getString(R.string.nameStr)+" "+nameVal);
        usn.setText(getString(R.string.usnStr)+" "+usnVal);
        dept.setText(getString(R.string.deptStr)+" "+deptVal);
    }
}
