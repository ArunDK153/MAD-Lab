package com.demo.labprog2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    Spinner s;
    String[] dept_array = {"CSE","ECE","ISE","Mech","Civil"};
    EditText name,usn;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        s = findViewById(R.id.dept_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_item,dept_array);
        s.setAdapter(adapter);
        name = findViewById(R.id.nameIn);
        usn = findViewById(R.id.usnIn);
        submit = findViewById(R.id.btn_submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,DetailsActivity.class);
                i.putExtra("name_key",name.getText().toString());
                i.putExtra("usn_key",usn.getText().toString());
                i.putExtra("dept_key",s.getSelectedItem().toString());
                startActivity(i);
            }
        });
    }
}
