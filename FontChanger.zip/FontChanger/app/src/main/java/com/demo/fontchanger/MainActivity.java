package com.demo.fontchanger;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText colorInput;
    private EditText fontInput;
    private Button btn_color;
    private Button btn_font;
    private TextView helloWorld ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        colorInput = findViewById(R.id.colorInput);
        fontInput = findViewById(R.id.fontInput);
        btn_color = findViewById(R.id.btn_chng_color);
        btn_font = findViewById(R.id.btn_chng_font);
        helloWorld = findViewById(R.id.helloWorldView);

        btn_color.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String color = colorInput.getText().toString();
                try{
                    helloWorld.setTextColor(Color.parseColor(color));
                }
                catch (IllegalArgumentException e){
                    Toast.makeText(MainActivity.this, "Unknown color!", Toast.LENGTH_SHORT).show();
                    helloWorld.setTextColor(Color.BLACK);
                }
            }
        });

        btn_font.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int font = Integer.parseInt(fontInput.getText().toString());
                if(font>60)
                {
                    font = 60;
                    Toast.makeText(MainActivity.this,"Max size is 60!",Toast.LENGTH_SHORT).show();
                }
                helloWorld.setTextSize(font);
            }
        });
    }
}
